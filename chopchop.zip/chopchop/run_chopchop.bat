@echo off
setlocal ENABLEDELAYEDEXPANSION

REM ===== ChopChop Launcher (place this .bat inside the chopchop folder) =====
cd /d "%~dp0"

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  set "PY=py"
) else (
  set "PY=python"
)

where %PY% >nul 2>nul
if not %ERRORLEVEL%==0 (
  echo [ERROR] Python is not installed or not on PATH.
  echo Install Python 3.10+ from python.org and try again.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [INFO] Creating virtual environment...
  %PY% -m venv ".venv"
  if not %ERRORLEVEL%==0 (
    echo [ERROR] Failed to create venv.
    pause
    exit /b 1
  )
)

echo [INFO] Installing dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install --upgrade -r requirements.txt
if not %ERRORLEVEL%==0 (
  echo [ERROR] Failed to install requirements.
  pause
  exit /b 1
)

echo [INFO] Starting ChopChop...
set "PYTHONUTF8=1"
".venv\Scripts\python.exe" -m streamlit run app.py

pause

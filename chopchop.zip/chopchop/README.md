# ChopChop – Smart Splitter (Readable Parts)

ChopChop is a Streamlit app that splits uploaded items into **readable parts** and produces **one output ZIP**.

## Readable splitting rules

- **PNG / JPG / JPEG**: decoded and cropped into tiles (every part is a valid image)
- **PDF**: split by pages into valid PDF parts
- **Text / code**: split into parts while trying to avoid breaking UTF‑8 characters
- **ZIP input**: treated as a folder container (not split by bytes). Contents are processed inside and included in the output.

For other binary formats (e.g. MP4), splitting by bytes cannot guarantee every part is independently playable.

## Run on Windows

1. Unzip the package
2. Open the `chopchop` folder
3. Double‑click `run_chopchop.bat`
4. Your browser will open the app

## Notes

- Streamlit uploads have a per‑file size limit (shown in the UI).
- If you upload huge folders (thousands of files), it may be slow.
